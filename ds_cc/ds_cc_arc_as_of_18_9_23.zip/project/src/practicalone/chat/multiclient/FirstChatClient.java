package practicalone.chat.multiclient;

import baseclasses.multiclient.Client;

public class FirstChatClient {

	public static void main(String[] args) {
		String url = ChatServer.url;
		int port = ChatServer.port;
		Client client = new Client();
		client.setUserName("Atman");
		client.chatWith("Spider-man");
		client.initializeConnection(url, port);
	}
}
